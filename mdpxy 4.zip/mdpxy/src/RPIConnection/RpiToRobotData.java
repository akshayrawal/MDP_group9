package RPIConnection;

public interface RpiToRobotData {
	
//	 static final String comFpTurnLeft = "H";
//	 static final String comFPTurnRight = "G";
//	 static final String comFpGoalCalibrate = "I";
	
	 static final String STRAIGHTMOVE = "M";
	 static final String STRAIGHTMOVEF = "P";
	 static final String TURNLEFT = "L";
	 static final String TURNRIGHT = "R";
	 static final String TURNBACK = "B";
	 static final String SCANARENA = "S";
	 static final String CALIBRATE = "C";
	 static final String SIDECALIBRATION="T";
	 static final String comFpGoalCalibrate = "I";
	 
}
